/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Umbrella header for the SoupKit framework
*/

#import <UIKit/UIKit.h>

//! Project version number for SoupKit.
FOUNDATION_EXPORT double SoupKitVersionNumber;

//! Project version string for SoupKit.
FOUNDATION_EXPORT const unsigned char SoupKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SoupKit/PublicHeader.h>
